// Auteur   : Maxime Faucher
// Date     : 2025-09-24
// Sujet    : Solution de l'exercice 9 - Cours 06

package exercicesCours06;

import java.util.Scanner;

public class Ex9 {

    // Créer un jeu de devinette : l’ordinateur choisit un nombre entre 1 et 100,
    // et l’utilisateur doit le deviner. La boucle continue tant que la réponse est
    // incorrecte (do...while).

    public static void main(String[] args) {

        // Mettons-y de la couleur!
        final int MIN = 1;
        final int MAX = 100;
        final String RESET = "\u001B[0m";
        final String CYAN = "\u001B[36m";
        final String ROUGE = "\u001B[31m";
        final String VERT = "\u001B[32m";
        final Scanner saisie = new Scanner(System.in);

        // Le nombre à deviner, la tentative du joueur (et un compteur,
        // pour le plaisir!)
        final int NOMBRE;
        int tentative = 0, compteur = 0;

        // On trouve un nombre au hasard
        NOMBRE = MIN + (int) (Math.random() * MAX - MIN + 1);

        // Essaie de le deviner!
        do {
            System.out.print(CYAN + "Quel est le nombre mystère ? " + RESET);
            if (saisie.hasNextInt()) { // Si la saisie est un entier
                tentative = saisie.nextInt();
                if (tentative >= MIN && tentative <= MAX) { // VALIDE
                    compteur++; // si on est ici, l'essai est une tentative réelle (entier entre MIN et MAX)
                    if (tentative == NOMBRE) { // le joueur a-t-il GAGNÉ?
                        System.out.printf(VERT + "Félicitations, tu as trouvé en %d essai(s)!%n%n%n" + RESET, compteur);
                    } else { // on avise le joueur de viser plus haut ou plus bas, selon le cas
                        System.out.println(
                                "Le nombre mystère est plus " + (tentative - NOMBRE > 0 ? "petit" : "grand") + "...");
                    }
                } else { // le nombre n'est pas entre MIN et MAX. On nargue le joueur un peu
                    System.out.printf(ROUGE + "Vraiment? C'est pourtant simple de saisir un nombre entre %d et %d. "
                            + RESET + "Recommence, STP...%n", MIN, MAX);
                }
            } else { // Si la saisie n'est PAS un entier
                System.out.printf(ROUGE + "ERREUR: saisie invalide. On cherche un nombre entre %d et %d. " + RESET
                        + "Recommence, STP.%n", MIN, MAX);
            }
            //saisie.nextLine(); // FTB! Sinon, tout s'écroule
        } while (tentative != NOMBRE);

        // So long!
        saisie.close();
        System.exit(0);
    }

}
