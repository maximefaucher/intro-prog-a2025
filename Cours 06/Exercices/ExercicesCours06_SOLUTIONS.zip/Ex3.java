// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 3 - Cours 06

package exercicesCours06;

public class Ex3 {

    public static void main(String[] args) {

        // Afficher les nombres pairs entre 2 et 20 avec une boucle while.
        
        int nombre = 2;
        final int INCREMENT = 2;
        System.out.println("Nombres pairs entre 2 et 20 :");
        while( nombre <= 20 ) {
            System.out.printf("%d ", nombre);
            nombre += INCREMENT;
        }
        
        System.exit(0);
    }

}
