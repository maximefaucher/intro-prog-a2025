// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 8 - Cours 06

package exercicesCours06;

public class Ex8 {

    public static void main(String[] args) {

        // Trouver le plus petit entier n tel que la somme des entiers de 1 à n dépasse 1000 (while).
        
        int somme = 0; // la somme débute à 0
        int n = 1; // on commence à 1

        while( somme < 1000 ) {
            somme += n; // on augmente la somme
            if(somme < 1000) { // sans ce test, on indiquerait 1 de trop dans la réponse
                n++;
            }
        }

        System.out.printf("Le nombre est %d et la somme est %d.", n, somme);
        
        System.exit(0);
    }
}
