// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 1 - Cours 06

package exercicesCours06;

public class Ex1 {

    public static void main(String[] args) {

        // Afficher les nombres de 1 à 10 à l’aide d’une boucle while.
        
        int n = 1;
        while(n <= 10) {
            System.out.printf("%d ", n);
            n++;
        }
        
        System.exit(0);
    }

}
