// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 6 - Cours 06

package exercicesCours06;

public class Ex6 {

    public static void main(String[] args) {

        // Afficher les puissances de 2 (2, 4, 8, 16, ...) jusqu’à ce que le résultat dépasse 1000 (while).

        int puissance = 0, exposant = 0;
        final int BASE = 2;
        final int VALEUR_ARRET = 1000;

        System.out.printf("PUISSANCES DE %d%n", BASE);
        while(puissance <= VALEUR_ARRET) {
            puissance = (int)Math.pow(BASE, exposant);  // ici on force la conversion en entier avec le cast (int)
                                                        // car on est CERTAIN que 2^x donne un entier si x est entier
            if(puissance <= VALEUR_ARRET) { // avec un do...while, on éviterait ce test
                System.out.printf("%d^%d = %d%n", BASE, exposant, puissance);
            }
            exposant++;
        }
        
        System.exit(0);
    }

}
