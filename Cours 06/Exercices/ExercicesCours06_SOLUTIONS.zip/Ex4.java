// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 4 - Cours 06

package exercicesCours06;

import java.util.Scanner;

public class Ex4 {

    public static void main(String[] args) {
        
        // Demander à l’utilisateur d’entrer des entiers positifs et calculer leur somme. 
        // La saisie s’arrête lorsqu’un nombre négatif est entré (do...while).

        int somme = 0;
        int nombre;
        Scanner scanner = new Scanner(System.in);
        do {
            System.out.print("Entrer un nombre entier (négatif pour quitter) : ");
            nombre = scanner.nextInt();
            somme += nombre >= 0 ? nombre : 0;
        } while (nombre >= 0);

        System.out.printf("La somme est %d.\n", somme);

        scanner.close();
        System.exit(0);
    }

}
