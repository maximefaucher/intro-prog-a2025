// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 10 - Cours 06

package exercicesCours06;

import java.util.Scanner;

public class Ex10 {

    // Simuler une machine distributrice : l’utilisateur entre un montant, puis choisit un produit.
    // La boucle continue tant que le solde est suffisant et que l’utilisateur veut continuer.

    public static void main(String[] args) {        
        // Constantes ANSI pour les couleurs du texte
        final String RESET = "\u001B[0m";
        final String ROUGE = "\u001B[31m";
        final String VERT = "\u001B[32m";

        final String MENU = "1. Eau (2,00$)\n2. Croustilles (3,00$)\n3. Chocolat (2,50$)\n4. Quitter";
        final double PRIX_EAU = 2.0, PRIX_CHIPS = 3.0, PRIX_CHOCO = 2.5;
        final Scanner saisie = new Scanner(System.in);
        double solde = -1;
        int choixMenu = -1;

        // Saisie / validation du solde
        while(solde < 0) {
            System.out.print("Saisir un solde de départ : ");
            if( saisie.hasNextDouble() ) {
                solde = saisie.nextDouble();
                if(solde < 0) {
                    System.out.println(ROUGE + "Le solde doit être positif." + RESET);
                }
            }
            else {
                System.out.println(ROUGE + "Solde invalide." + RESET);
            }
            saisie.nextLine(); // FTB
        }

        do {
            System.out.println("\nMACHINE DISTRIBUTRICE");
            System.out.println(MENU);
            System.out.printf("Choisir une option [%ssolde = %.2f$%s] : ", VERT, solde, RESET);
            if(saisie.hasNextInt()) {
                choixMenu = saisie.nextInt();
                if(choixMenu == 1) {
                    if(solde >= PRIX_EAU)
                        solde -= PRIX_EAU;
                    else
                        System.out.println(ROUGE + "Solde insuffisant pour cet article..." + RESET);
                }
                else if(choixMenu == 2) {
                    if(solde >= PRIX_CHIPS)
                        solde -= PRIX_CHIPS;
                    else
                        System.out.println(ROUGE + "Solde insuffisant pour cet article..." + RESET);

                }
                else if(choixMenu == 3) {
                    if(solde >= PRIX_CHOCO)
                        solde -= PRIX_CHOCO;
                    else
                        System.out.println(ROUGE + "Solde insuffisant pour cet article..." + RESET);
                }
                else {
                    if(choixMenu != 4) {
                        System.out.println(ROUGE + "Choix invalide!" + RESET);
                    }
                    else {
                        System.out.printf("Au revoir! Votre solde restant est de %.2f$.%n", solde);
                    }
                }
            }
            else {
                System.out.println(ROUGE + "Choix invalide. " + RESET + "Entrer un choix entre 1 et 4.");
            }
            saisie.nextLine(); // estion du tampon
        } while (choixMenu != 4);
        
        // Au revoir
        saisie.close();
        System.exit(0);
    }

}
