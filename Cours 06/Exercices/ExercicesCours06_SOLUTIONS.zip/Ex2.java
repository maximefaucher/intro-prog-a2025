// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 2 - Cours 06

package exercicesCours06;

import java.util.Scanner;

public class Ex2 {

    public static void main(String[] args) {
        
        // Demander à l’utilisateur d’entrer un mot de passe jusqu’à ce qu’il entre "java123" (utiliser do...while).

        final String MDP_REFERENCE = "java123";
        String mdp;
        Scanner sc = new Scanner(System.in);
        
        do {
            System.out.print("Entrer le mot de passe : ");
            mdp = sc.next();
            sc.nextLine(); // FTB!!
        } while( !mdp.equals(MDP_REFERENCE) );

        System.out.println("Bravo! tu as trouvé le mot de passe secret!");

        sc.close();
        System.exit(0);

    }

}
