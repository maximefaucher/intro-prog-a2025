// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 7 - Cours 06

package exercicesCours06;

import java.util.Scanner;

public class Ex7 {

    public static void main(String[] args) {
        
        // Demander à l’utilisateur d’entrer des notes (entre 0 et 100). 
        // Calculer la moyenne. La saisie s’arrête quand l’utilisateur entre -1. 
        // Ignorer les valeurs invalides.

        Scanner scanner = new Scanner(System.in);
        int note = -1, nbNotes = 0;
        double somme = 0;

        // Saisie
        do {
            System.out.print("Entrer une note entre 0 et 100 (-1 pour quitter) : ");
            if( scanner.hasNextInt() ) {
                note = scanner.nextInt();
                if( note == -1 ) {
                    break;
                }
                if( note >= 0 && note <= 100 ) { // VALIDE
                    somme += note;
                    nbNotes++;
                }
            }
            scanner.nextLine(); // FTB!
        } while(note != -1);

        // Affichage
        if(nbNotes > 0) {
            System.out.printf("La moyenne des notes valides saisies est %.3f%n", somme/nbNotes);
        }

        scanner.close();
        System.exit(0);
    }

}
