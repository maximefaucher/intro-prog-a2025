// Auteur   : Maxime Faucher
// Date     : 2025-09-19
// Sujet    : Solution de l'exercice 5 - Cours 06

package exercicesCours06;

import java.time.LocalDate;
import java.util.Scanner;

public class Ex5 {

    public static void main(String[] args) {
        
        /* 
         * Créer un menu interactif avec les options suivantes : 
         * 
         * 1- Afficher un message
         * 2- Afficher la date
         * 3- Quitter
         * 
         * Utiliser une boucle do...while pour répéter le menu jusqu’à ce que l’utilisateur choisisse 3.
         */

        final String OPTIONS_MENU = "1. Afficher un message\n2. Afficher la date\n3. Quitter";
        int choixMenu;
        final int OPTION_QUITTER = 3;
        Scanner saisie = new Scanner(System.in);

        do {
            System.out.println("\n" + OPTIONS_MENU);
            System.out.print("Votre choix : ");
            choixMenu = saisie.nextInt();
            switch (choixMenu) {
                case 1:
                    System.out.println("Ceci est un message.");
                    break;
                case 2:
                    System.out.printf("La date courante est %s.\n", LocalDate.now());
                    break;
                default:
                    // Ne fera rien si autre chose que 1 ou 2
                    break;
            }
        } while( choixMenu != OPTION_QUITTER);

        saisie.close();
        System.exit(0);
    }
}
